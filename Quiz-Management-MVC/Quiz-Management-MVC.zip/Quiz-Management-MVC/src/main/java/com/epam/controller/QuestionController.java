package com.epam.controller;

import com.epam.model.Question;
import com.epam.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
public class QuestionController {

    @Autowired
    QuestionService questionService;

    @GetMapping("/questions")
    public String questionList(Model model) {
        model.addAttribute("questions", questionService.read());
        return "questionList";
    }

    @GetMapping("/question/new")
    public String createQuestion(Model model) {
        Question question = new Question();
        model.addAttribute("question", question);
        return "createQuestion";
    }

    @PostMapping("/question")
    public String saveQuestion(@ModelAttribute("question") Question question) {
        questionService.create(question);
        return "redirect:/questions";
    }

    @GetMapping("/question/delete/{id}")
    public String deleteUser(@PathVariable int id) {
        questionService.delete(id);
        return "redirect:/questions";
    }


}



