package com.epam.controller;

import com.epam.model.User;
import com.epam.service.UserAuthentication;
import com.epam.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class UserAuthenticationController {

    @Autowired
    UserAuthentication userAuthentication;
    @Autowired
    UserService userService;

    @GetMapping("/login/user")
    public String login(Model model) {
        User user = new User();
        model.addAttribute("user", user);
        return "login";

    }

    @PostMapping("/admin")
    public ModelAndView validateUser(@ModelAttribute("user") User user) {
        System.out.println(user.getUserName());
        ModelAndView modelAndView = new ModelAndView();
        if (userAuthentication.isUserExsist(user.getUserName())) {
            modelAndView.addObject("validate", true);
            modelAndView.setViewName("adminPanel");
        }

        return modelAndView;
    }

    @GetMapping("/question")
    public String questionPanel() {
        return "question";
    }

    @GetMapping("/quiz")
    public String quizPanel() {
        return "quiz";
    }

    @GetMapping("/user")
    public String userPanel() {
        return "user";
    }
}
