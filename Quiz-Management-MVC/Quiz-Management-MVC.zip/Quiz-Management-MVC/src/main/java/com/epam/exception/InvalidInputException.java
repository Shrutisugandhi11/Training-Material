package com.epam.exception;

public class InvalidInputException extends Exception {

	public InvalidInputException() {
		super();
	}

	public InvalidInputException(String str) {
		super(str);
	}


}
