INSERT INTO user (password,roleType,userName) VALUES("admin", "admin", "admin");
INSERT INTO user (password,roleType,userName) VALUES("abc@123", "user",  "Shruti");


