package com.epam.quiz.management.dao;

import com.epam.quiz.management.model.Option;
import com.epam.quiz.management.model.Question;
import com.epam.quiz.management.model.Quiz;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
 class QuizDbTest {

 @InjectMocks
 private QuizDao quizDao;
 @Mock
 private EntityManager entityManager;
 @Mock
 private EntityManagerFactory entityManagerFactory;
 @Mock
 private EntityTransaction transaction;
 private List<Quiz> quizes;

 @BeforeEach
 void setup() {
  quizes = new ArrayList<>();
  quizes.add(getMockQuiz());
  when(entityManagerFactory.createEntityManager()).thenReturn(entityManager);
 }

 public Quiz getMockQuiz() {
  Option option1 = new Option("1");
  Option option2 = new Option("2");
  Option option3 = new Option("3");
  Option option4 = new Option("4");
  List<Option> options = Arrays.asList(option1, option2, option3, option4);
  List<Question> questions = Arrays.asList(new Question("5+6?",options,"easy","java",1));
  return new Quiz("java","easy",questions);
 }

 @Test
 void testCreateQuiz() {
  when(entityManager.getTransaction()).thenReturn(transaction);
  quizDao.create(quizes.get(0));
  verify(entityManager).persist(quizes.get(0));
  verify(entityManager).close();
  verify(transaction).begin();
  verify(transaction).commit();
 }

 @Test
 void testDeleteQuizById() {
  when(entityManager.getTransaction()).thenReturn(transaction);
  when(entityManager.find(any(), anyInt())).thenReturn(quizes.get(0));
  quizDao.delete(quizes.get(0).getId());
  verify(entityManager).remove(quizes.get(0));
  verify(entityManager).close();
  verify(transaction).begin();
  verify(transaction).commit();
 }
 @Test
 void testGetQuizByTag() {
  TypedQuery query = mock(TypedQuery.class);
  when(query.getResultList()).thenReturn(quizes);
  when(entityManager.createQuery(anyString(), any())).thenReturn(query);
  quizDao.readByTag(quizes.get(0).getTag());
  verify(query).getResultList();

 }

 @Test
 void testGetQuizById() {
  when(entityManager.find(any(), anyInt())).thenReturn(quizes.get(0));
  int id = quizes.get(0).getId();
  quizDao.readById(id);
  verify(entityManager).find(Quiz.class, id);
  verify(entityManager).close();
 }

 @Test
 void testGetAllQuizes() {

  TypedQuery query = mock(TypedQuery.class);
  when(query.getResultList()).thenReturn(quizes);
  when(entityManager.createQuery(anyString(), any())).thenReturn(query);
  quizDao.read();
  verify(query).getResultList();

 }
 @Test
 void testUpdateQuiz() {
  when(entityManager.getTransaction()).thenReturn(transaction);
  when(entityManager.find(any(), anyInt())).thenReturn(quizes.get(0));
  quizDao.update(quizes.get(0).getId(), "python");
  verify(transaction).begin();
  verify(transaction).commit();
  verify(entityManager).close();
 }
 @Test
 void testGetAllQuestion() {
  TypedQuery query = mock(TypedQuery.class);
  when(query.getResultList()).thenReturn(quizes);
  when(entityManager.createQuery(anyString(), any())).thenReturn(query);
  quizDao.getQuestionList(quizes.get(0).getTag());
  verify(query).getResultList();
 }

}







