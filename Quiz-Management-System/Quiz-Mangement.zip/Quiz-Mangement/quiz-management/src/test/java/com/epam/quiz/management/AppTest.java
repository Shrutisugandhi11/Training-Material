package com.epam.quiz.management;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

 class AppTest {

  @Test
 void shouldAnswerWithTrue() {
    assertTrue(true);
  }
}
