package com.epam.quiz.management.dao;

import com.epam.quiz.management.model.Option;
import com.epam.quiz.management.model.Question;
import com.epam.quiz.management.model.Quiz;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.TypedQuery;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class QuestionDbTest {
    @InjectMocks
    private QuestionDao questionDao;
    @Mock
    private EntityManager entityManager;
    @Mock
    private EntityManagerFactory entityManagerFactory;
    @Mock
    private EntityTransaction transaction;
    @Mock
    private TypedQuery<Question> typedQuestion;
    private List<Question> questions;

    @BeforeEach
    void setup() {
        questions = new ArrayList<>();
        questions.add(getMockQuestion());
        when(entityManagerFactory.createEntityManager()).thenReturn(entityManager);
    }

    public Question getMockQuestion() {
        Option option1 = new Option("1");
        Option option2 = new Option("2");
        Option option3 = new Option("3");
        Option option4 = new Option("4");
        List<Option> options = Arrays.asList(option1, option2, option3, option4);
        return new Question("5+6?",options,"easy","java",1);
    }

    @Test
    void testCreateQuestion() {
        when(entityManager.getTransaction()).thenReturn(transaction);
        questionDao.create(questions.get(0));
        verify(entityManager).merge(questions.get(0));
        verify(entityManager).close();
        verify(transaction).begin();
        verify(transaction).commit();
    }



    @Test
    void testGetQuestionById() {
        when(entityManager.find(any(), anyInt())).thenReturn(questions.get(0));
        int id = questions.get(0).getId();
        questionDao.readById(id);
        verify(entityManager).find(Question.class, id);
        verify(entityManager).close();
    }

    @Test
    void testGetAllQuestions() {
        String queryString = "from Question q";
        TypedQuery query = mock(TypedQuery.class);
        when(query.getResultList()).thenReturn(questions);
        when(entityManager.createQuery(anyString(), any())).thenReturn(query);
        questionDao.read();
        verify(query).getResultList();

    }


}

