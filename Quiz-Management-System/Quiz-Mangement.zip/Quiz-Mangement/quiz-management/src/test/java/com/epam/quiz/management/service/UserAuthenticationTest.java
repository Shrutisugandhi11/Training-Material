package com.epam.quiz.management.service;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
 class UserAuthenticationTest {
 @Mock
 UserAuthentication userAuthentication;
 @Test
 void  validate(){
  String name="Shruti";
  String pass="5678";
  String role="user";
//  when(userAuthentication.validateUser(name,pass,role)).thenReturn(true);
// assertTrue(userAuthentication.validateUser(name,pass,role));
 }


}
