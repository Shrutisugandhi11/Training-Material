package com.epam.quiz.management.service;

import com.epam.quiz.management.dao.UserDaoImpl;
import com.epam.quiz.management.model.User;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.stubbing.OngoingStubbing;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @InjectMocks
    UserService userService;
    @Mock
    UserDaoImpl userDao;
    User user;
    List<User> users;

    @BeforeEach
    void setup() {
        user = new User();
        user.setUserName("xxx");
        user.setPassword("111");
        users = new ArrayList<>();
        users.add(user);
    }

    @Test
    void create(){
    assertEquals("User registered Successfully!! ",userService.register(user.getUserName(),user.getPassword()));

    }

    @Test
    void delete() {
        when(userDao.delete("xxx")).thenReturn(user);
        assertEquals(user, userService.removeUser("xxx"));

    }

    }











