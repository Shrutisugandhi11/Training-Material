INSERT INTO user (password,roleType,userName) VALUES("root", "Admin", "root");
INSERT INTO user (password,roleType,userName) VALUES("abc@123", "user",  "Shruti");


