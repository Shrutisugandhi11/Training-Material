package com.epam.quiz.management.dao;

import com.epam.quiz.management.model.Question;
import com.epam.quiz.management.model.User;
import com.epam.quiz.management.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import java.util.List;

public class UserDaoImpl implements UserDao<User, String> {


    EntityManagerFactory entityManagerFactory = JPAUtil.getInstance();

    EntityManager entityManager;

    @Override
    public User create(User user) {
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(user);
        entityManager.getTransaction().commit();
        entityManager.close();
        return user;

    }

    @Override
    public User findById(String id) {
        entityManager = entityManagerFactory.createEntityManager();
        User user = entityManager.find(User.class, id);
        entityManager.close();
        return user;
    }

    @Override
    public List<User> findAll() {
        entityManager = entityManagerFactory.createEntityManager();
        return entityManager.createQuery("from User user", User.class).getResultList();

    }

    @Override
    public User delete(String userName) {
        entityManager = entityManagerFactory.createEntityManager();
        User user = entityManager.find(User.class, userName);
        entityManager.getTransaction().begin();
        entityManager.remove(user);
        entityManager.getTransaction().commit();
        entityManager.close();
        return user;

    }


    @Override
    public boolean deleteById(int id) {
        entityManager = entityManagerFactory.createEntityManager();
        boolean isUser = false;
        Question question = entityManager.find(Question.class, id);
        if (question == null) {
            isUser = false;
        } else {
            entityManager.getTransaction().begin();
            entityManager.remove(question);
            entityManager.getTransaction().commit();
            entityManager.close();
            isUser = true;
        }
        return isUser;
    }

}

