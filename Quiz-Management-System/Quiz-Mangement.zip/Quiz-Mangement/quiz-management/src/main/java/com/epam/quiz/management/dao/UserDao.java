package com.epam.quiz.management.dao;

import java.util.List;

public interface UserDao<T,U> {

	public T create(T obj);

	public T findById(U userName);

	public List<T> findAll();

	public T delete(U userName);

	public boolean deleteById(int id);
}
