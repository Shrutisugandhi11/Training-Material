package com.epam.quiz.management.model;

import jakarta.persistence.*;

@Entity
@Table(name="options")
public class Option {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column
    private int optionId;
    @Column
    private String choice;
	@ManyToOne
	private Question question;

    public int getOptionId() {
        return optionId;
    }

    public void setOptionId(int optionId) {
        this.optionId = optionId;
    }

    public Question getQuestion() {
        return question;
    }

    public void setQuestion(Question question) {
        this.question = question;
    }

    public Option(String choice) {
         this.choice = choice;
    }

    public Option() {
    }

    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {

        this.choice = choice;
    }

    @Override
    public String toString() {
        return "Option choice=" + choice + "";
    }

}
