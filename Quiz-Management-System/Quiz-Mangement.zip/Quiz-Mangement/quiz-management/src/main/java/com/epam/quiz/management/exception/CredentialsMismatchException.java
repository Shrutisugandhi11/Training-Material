package com.epam.quiz.management.exception;

public class CredentialsMismatchException extends Exception {

	public CredentialsMismatchException() {
super();
	}

	public CredentialsMismatchException(String str) {
	super(str);
	}
}
