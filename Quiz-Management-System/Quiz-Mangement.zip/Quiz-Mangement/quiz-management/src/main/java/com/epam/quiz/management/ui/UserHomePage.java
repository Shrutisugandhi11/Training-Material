package com.epam.quiz.management.ui;

import com.epam.quiz.management.exception.CredentialsMismatchException;
import com.epam.quiz.management.exception.InvalidInputException;
import com.epam.quiz.management.exception.ValidationException;
import com.epam.quiz.management.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.NoSuchElementException;

public class UserHomePage {
    private static final Logger LOGGER = LogManager.getLogger(UserHomePage.class);
    Menu menu = new Menu();

    public void redirectUser() {

        LOGGER.debug("==================Welcome To User Page======================");
        LOGGER.info("Hello:");

        LOGGER.info("\nDo you want to take quiz? \nPress:Y/N \nYour Choice:");
        String choiceString = Scanner.getInstance().nextLine();

        if (choiceString.equalsIgnoreCase("y")) {

            QuizGenerator quizGenerator = new QuizGenerator();
            quizGenerator.getQuiz();
            quizGenerator.getQuestion();
        } else {
            System.exit(1);
        }
    }

    public void redirectAdmin() throws InvalidInputException, ValidationException, CredentialsMismatchException {

        LOGGER.debug("======================Welcome To Admin Page======================");

        LOGGER.info("Hello:");

        LOGGER.info(
                "What operation do you wan to perform? \n 1.Go To Question Section \n 2.Go To Quiz Section \n 3.Manage User \n 4.Exit");
        int operation = 0;
        operation = Scanner.getInstance().nextInt();


        AdminUI adminUi = new AdminUI();
        try {


            switch (operation) {
                case 1:
                    adminUi.getQuestionCrud();
                    break;

                case 2:
                    adminUi.getQuizCrud();
                    break;

                case 3:
                    adminUi.prompt();
                    break;
                case 4:
                    menu.getDashboard();
                    break;


                default:
                    throw new InvalidInputException("Please enter Valid credetianls");

            }}
  catch (NoSuchElementException e){
                LOGGER.error(e.getMessage());
                redirectAdmin();
            }


    }}