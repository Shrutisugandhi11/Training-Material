package com.epam.quiz.management.exception;

public class InvalidInputException extends Exception {

	public InvalidInputException() {
		super();
	}

	public InvalidInputException(String str) {
		super(str);
	}


}
