package com.epam.quiz.management.ui;

import com.epam.quiz.management.model.Question;
import com.epam.quiz.management.model.Quiz;
import com.epam.quiz.management.service.QuizService;
import com.epam.quiz.management.util.Scanner;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class QuizUI {
    private static final Logger LOGGER = LogManager.getLogger(QuizUI.class);
    Quiz quiz;
    List<Question> questions = new ArrayList<>();
    QuizService quizService = new QuizService();


    public String create() {

        LOGGER.debug("--------------------------------");
        Scanner.getInstance().nextLine();

        LOGGER.info("Enter Quiz Tag:");
        String tag = Scanner.getInstance().nextLine();
        LOGGER.info("Enter Quiz Difficulty:");
        String difficulty = Scanner.getInstance().nextLine();
        questions = quizService.getQuestionList(tag);

        Quiz quiz1 = new Quiz(tag, difficulty, questions);
        quizService.create(quiz1);
        return "Quiz Created Successfully";
    }

    public void read() {

        LOGGER.debug("------------------------------");
        LOGGER.info("Enter tag of quiz you want?:");
        Scanner.getInstance().nextLine();

        String tag = Scanner.getInstance().nextLine();
        List<Quiz> quizList = quizService.readByTag(tag);

        quizList.forEach(LOGGER::info);
    }

    public void showQuestions() {


        int score = 0;
        int totalMarks = 0;
        int userAnswer = 0;
        LOGGER.info("Please Enter Quiz Id You want to take?");
        int id = Scanner.getInstance().nextInt();
        Quiz quizzes = quizService.readById(id);
        List<Question> questionList =  quizzes.getQuestions();

        int iterator = 0;
        for (Question question : questionList) {
            iterator++;
            LOGGER.info("===================================================");
            LOGGER.log(Level.INFO, "Question {}:{} ", iterator, question.getTitle());
            LOGGER.info("===================================================");

            LOGGER.info("-------------------------------");
            question.getOption().forEach(LOGGER::info);
            LOGGER.info("-------------------------------");

            LOGGER.info("Please Select Option 1|2|3|4  to Move to another Question:");
            userAnswer = Scanner.getInstance().nextInt();

            if (userAnswer == question.getAnswer()) {
                score++;
                totalMarks++;
                LOGGER.log(Level.INFO, "Correct,Your Score:{}", score);
            } else {
                totalMarks++;
                LOGGER.info("OOps,It's Incorrect");
            }
        }
        LOGGER.info("=======================================");
        LOGGER.log(Level.INFO, "Your score : {} / {}", score, totalMarks);
        LOGGER.info("=======================================");
    }

    public String delete() {
        LOGGER.debug("----------------------------------");
        LOGGER.info("Enter the question id which you want to remove : ");

        int removeId = Scanner.getInstance().nextInt();
        quiz = quizService.readById(removeId);

        if (quiz == null) {
            LOGGER.log(Level.INFO, "Question with id :{} is not found ", removeId);
        }

        return quizService.delete(removeId);
    }
}