package com.epam.quiz.management.ui;

import com.epam.quiz.management.exception.CredentialsMismatchException;
import com.epam.quiz.management.exception.InvalidInputException;
import com.epam.quiz.management.exception.ValidationException;
import com.epam.quiz.management.service.UserAuthentication;
import com.epam.quiz.management.service.UserService;
import com.epam.quiz.management.util.Scanner;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;

public class Menu {
    private static final Logger LOGGER = LogManager.getLogger(Menu.class);
    UserAuthentication userAuthentication = new UserAuthentication();

    public void getDashboard() throws InvalidInputException, ValidationException, CredentialsMismatchException {
        int choice;

        while (true) {
            LOGGER.debug("=================WelCome to quiz=================");

            LOGGER.info("\n Enter your choice: \n1.User \n2.Admin \n3.Register User \n4.Exit");
            LOGGER.info("Your Choice: ");

            choice = Scanner.getInstance().nextInt();
            try {
                if (choice > 4 || choice < 0) throw new InvalidInputException("Enter valid input :");
            } catch (InvalidInputException e) {
                LOGGER.error(e.getMessage());
                getDashboard();
            }

            if (choice == 4) {
                LOGGER.debug("Exited From Quiz!!");
                break;
            }
            Scanner.getInstance().nextLine();

            try {
                userOperations(choice);
            } catch (CredentialsMismatchException | NullPointerException | ValidationException |
                     NoSuchElementException e) {
                LOGGER.error(e.getMessage());
                userOperations(choice);
            }

        }
    }

    void userOperations(int choice) throws InvalidInputException, ValidationException, CredentialsMismatchException {
        String userName;
        String passwordString;
        UserService userService;
        String role = (choice == 1) ? "user" : "admin";
        LOGGER.debug("==================Welcome To Login Page====================");
        LOGGER.info("Username should contain:\n " +
                "-one UpperCase letter.\n-lowercase letter.\n-one digit from 0-9." +
                "\n-length should be min 6 letters to max 19 letters");

        LOGGER.info("Your Username:");
        userName = Scanner.getInstance().nextLine();
        LOGGER.info("your password must contains:\n"
                + "-one lowercase letter.\n-one digit from 0-9.\n -one special character. "
                + "\n-one capital letter.\n-length should be min 6 letters to max 19 letters");
        LOGGER.info("Your Password: ");
        passwordString = Scanner.getInstance().nextLine();


        if (choice == 3) {
            if (userAuthentication.validateCredentials(userName, passwordString)) {
                userService = new UserService();
                if (userAuthentication.isUserExsist(userName)) {
                    throw new NoSuchElementException("User already Exsists!!");
                } else {
                    LOGGER.log(Level.INFO, "{}", userService.register(userName, passwordString));
                }
            } else {
                throw new ValidationException("Incorrect credentials!!");
            }
        } else {
            boolean isValidateUser = userAuthentication.validateUser(userName, passwordString, role);
            if (!isValidateUser) {
                throw new CredentialsMismatchException("user login error");
            }
            UserHomePage userHomePage = new UserHomePage();
            if ("admin".equals(role)) {
                try {
                    userHomePage.redirectAdmin();

                } catch (InputMismatchException e) {
                    LOGGER.info("Only integer data is allowed!");
                    Scanner.getInstance().nextLine();
                    userHomePage.redirectAdmin();
                }
            } else {
                userHomePage.redirectUser();
            }
        }
    }


}
