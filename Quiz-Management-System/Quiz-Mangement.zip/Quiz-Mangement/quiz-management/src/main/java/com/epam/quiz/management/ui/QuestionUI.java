package com.epam.quiz.management.ui;

import com.epam.quiz.management.exception.InvalidInputException;
import com.epam.quiz.management.model.Option;
import com.epam.quiz.management.model.Question;
import com.epam.quiz.management.service.QuestionService;
import com.epam.quiz.management.util.Scanner;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;

public class QuestionUI {
    private static final Logger LOGGER = LogManager.getLogger(QuestionUI.class);

    QuestionService questionService = new QuestionService();
    List<Option> listOfOptions = new ArrayList<>();

    private Question question;

    public String create() {

        LOGGER.debug("-------------------------------");
        question = new Question();
        Scanner.getInstance().nextLine();
        LOGGER.info("Enter the question title : ");
        String title = Scanner.getInstance().nextLine();
        question.setTitle(title);
        LOGGER.info("Enter the question Diffculty : ");
        String difficulty = Scanner.getInstance().nextLine();
        question.setDifficulty(difficulty);
        LOGGER.info("Enter the question tag : ");
        String tag = Scanner.getInstance().nextLine();
        question.setTag(tag);

        LOGGER.info("Enter the options : ");
        for (int i = 1; i <= 4; i++) {
            LOGGER.log(Level.INFO, "option {}:", i);
            String choice = Scanner.getInstance().nextLine();
            Option option1 = new Option();
            option1.setChoice(choice);
            listOfOptions.add(option1);
        }
        LOGGER.info("Enter the question answer : ");
        int answer = Scanner.getInstance().nextInt();
        Scanner.getInstance().nextLine();
        question.setAnswer(answer);
        question.setOption(listOfOptions);
        return questionService.create(question);
    }

    public String update() throws InvalidInputException {
        LOGGER.debug("---------------------------------");

        LOGGER.info("Enter Question id:");
        int id = Scanner.getInstance().nextInt();

        LOGGER.info("Enter which value to update");
        LOGGER.info("1.tittle \n 2.tag \n3.difficulty \n4.options \n5.Answer");
        int choice = Scanner.getInstance().nextInt();
        Scanner.getInstance().nextLine();
        LOGGER.info("Enter New value to update");
        String updateString = Scanner.getInstance().nextLine();

        if ((choice <= 5) && (choice > 0)) {
            if (choice == 4) {
                LOGGER.info("Enter which option to update");
                LOGGER.info("1.Option1 \n 2.Option2 \n3.Option3 \n4.Option4 ");
                choice = Scanner.getInstance().nextInt();
                questionService.updateOption(id, updateString, choice);
            } else {
                question = questionService.updateQuestion(id, updateString, choice);

            }
        } else {
            throw new InvalidInputException();
        }
        return "Question Updated Successfully!!";
    }

    public String delete() {
        LOGGER.debug("------------------------------");
        LOGGER.info("Enter the question id which you want to remove : ");
        int removeId = Scanner.getInstance().nextInt();
        return questionService.delete(removeId);
    }

    public void read() {
        LOGGER.debug("---------------------------------");
        List<Question> list = questionService.read();
        list.stream().forEach(LOGGER::info);
    }

}
