package com.epam.quiz.management.service;

import com.epam.quiz.management.exception.CredentialsMismatchException;
import com.epam.quiz.management.model.User;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UserAuthentication {
    private static final Logger Logger = LogManager.getLogger(UserAuthentication.class);
    UserService userService;

    public UserAuthentication() {
        userService = new UserService();
    }

    public boolean validateUser(String username, String password, String roleType) throws CredentialsMismatchException {
        User user;

        List<User> users = userService.getUsersList();
        boolean isValidate = false;

        Optional<User> optionalUser = users.stream().filter(x -> roleType.equals(x.getRoleType()))
                .filter(x -> username.equals(x.getUserName())).findAny();

        if (optionalUser.isPresent()) {
            user = optionalUser.get();

            if (username.equals(user.getUserName()) && password.equals(user.getPassword())) {
                if ("admin".equals(user.getRoleType()) || "user".equals(user.getRoleType()))
                    isValidate = true;

            } else
                throw new CredentialsMismatchException("Invalid credentials ,Please Enter valid credentials!!!");

        } else
            throw new CredentialsMismatchException("Error while validating user please retry....");


        return isValidate;
    }

    public boolean validateCredentials(String userName, String passwordString) {
        String usernameRegex = "^[A-Za-z]\\w{5,29}$";
        String passwordRegex = "^(?=.*[0-9])"
                + "(?=.*[a-z])(?=.*[A-Z])"
                + "(?=.*[@#$%^&+=])"
                + "(?=\\S+$).{6,20}$";
        Pattern userNamePattern = Pattern.compile(usernameRegex);
        Matcher userNameMatcher = userNamePattern.matcher(userName);
        Pattern passwordPattern = Pattern.compile(passwordRegex);
        Matcher passwordMatcher = passwordPattern.matcher(passwordString);
        return userNameMatcher.matches() && passwordMatcher.matches();
    }

    public boolean isUserExsist(String userName) {
        boolean flag = false;
        UserService user = new UserService();
        for (User usr : user.getUsersList()) {
            if (userName.equals(usr.getUserName())) {
                flag = true;
                break;
            }
        }
        return flag;

    }


}