package com.epam.quiz.management.dao;

import java.util.List;

public interface CrudDao<T> {

	public String create(T obj);

	public List<T> read();

	public T readById(int id);

	public T update(int id, String value);

	public String delete(int id);

}
