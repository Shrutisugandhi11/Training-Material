package com.epam.quiz.management.ui;

import com.epam.quiz.management.exception.CredentialsMismatchException;
import com.epam.quiz.management.exception.InvalidInputException;
import com.epam.quiz.management.exception.ValidationException;
import com.epam.quiz.management.service.UserService;
import com.epam.quiz.management.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.InputMismatchException;
import java.util.NoSuchElementException;

public class AdminUI {
    private static final Logger LOGGER = LogManager.getLogger(AdminUI.class);
    UserHomePage userHomePage = new UserHomePage();

    public void getQuizCrud() throws ValidationException, InvalidInputException, CredentialsMismatchException {

        LOGGER.debug("=============================================");

        QuizUI quizCrud = new QuizUI();
        boolean isBool = true;

            while (isBool) {

                LOGGER.info("Which Operation do You want to perform?");
                LOGGER.info("Enter: \n 1.Create Quiz \n 2.View Quiz \n 3.Delete a Quiz \n 4.logout \nYour Choice:");

                int key = Scanner.getInstance().nextInt();

                switch (key) {
                    case 1:

                        LOGGER.debug(quizCrud.create());
                        break;

                    case 2:
                        quizCrud.read();
                        break;

                    case 3:

                        LOGGER.debug(quizCrud.delete());
                        break;

                    case 4:
                        isBool = false;
                        LOGGER.debug("----------------Thank you-----------------");
                        userHomePage.redirectAdmin();
                        break;

                    default:
                        throw new InvalidInputException("Invalid credentials");
                }


            }
        }


    public void getQuestionCrud() throws InvalidInputException, ValidationException, CredentialsMismatchException {

            QuestionUI questionCrud = new QuestionUI();

            boolean isBool = true;
            while (isBool) {
                LOGGER.debug("==============================================");
                LOGGER.info("Which operation do you want to perform?");
                LOGGER.info(
                        " 1.Create a Question \n 2.View a Question \n 3.Modify a Question \n 4.Remove a Question \n 5.Logout");
                int option = Scanner.getInstance().nextInt();

                    switch (option) {
                        case 1:
                            LOGGER.debug(questionCrud.create());
                            break;
                        case 2:
                            questionCrud.read();
                            break;
                        case 3:
                            LOGGER.debug(questionCrud.update());
                            break;

                        case 4:
                            LOGGER.debug(questionCrud.delete());
                            break;

                        case 5:
                            isBool = false;
                            LOGGER.debug("------------Thank you--------------");
                            userHomePage.redirectAdmin();
                            break;

                        default:
                            throw new InvalidInputException("Invalid credentials");

                    }

                }

    }



    public void prompt() {
        UserService userService = new UserService();
        try {
            boolean isBool = true;
            while (isBool) {
                LOGGER.debug("============================================");
                LOGGER.info(
                        "What operation do you wan to perform? \n 1.registerUser  \n 2.getAllUsers \n 3.removeUser \n 4.Exit");
                int option = Scanner.getInstance().nextInt();
                Scanner.getInstance().nextLine();

                    switch (option) {
                        case 1:
                            LOGGER.info("Enter Username");
                            String username = Scanner.getInstance().nextLine();
                            LOGGER.info("Enter Passward");
                            String passwordString = Scanner.getInstance().nextLine();
                            LOGGER.debug(userService.register(username, passwordString));

                            break;
                        case 2:
                            userService.getAllUsers();
                            break;

                        case 3:
                            LOGGER.info("Enter User to be deleted:");
                            String usernameString = Scanner.getInstance().nextLine();
                            LOGGER.debug(userService.removeUser(usernameString));
                            break;

                        case 4:
                            isBool = false;
                            LOGGER.debug("------------Thank you--------------");
                            break;

                        default:
                            throw new InvalidInputException("Please Enter Crendetials");
                    }
                }

            }

        } catch (InputMismatchException e) {
            LOGGER.error("InvalidInput!!");

        }

    }





}