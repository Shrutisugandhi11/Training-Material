package com.epam.quiz.management.service;

import com.epam.quiz.management.dao.QuestionDao;
import com.epam.quiz.management.model.Question;

import java.util.List;

public class QuestionService {
    QuestionDao questionDao =new QuestionDao();
    public String create(Question question) {
       return questionDao.create(question);
    }
    public Question update(int id, String updateString) {
        return questionDao.update(id,updateString);
    }
    public Question updateQuestion(int id, String updateString,int choice) {
        return questionDao.updateQuestion(id,updateString,choice);
    }
    public Question updateOption(int id, String updateString,int choice) {
        return questionDao.updateOptions(id,updateString,choice);
    }
    public String delete(int removeId){
        return  questionDao.delete(removeId);
    }
    public List<Question> read() {
        return  questionDao.read();
    }

}
