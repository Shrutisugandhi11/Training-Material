package com.epam.quiz.management.ui;

import com.epam.quiz.management.model.Quiz;
import com.epam.quiz.management.service.QuizService;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.List;

public class QuizGenerator {
	private static final Logger LOGGER = LogManager.getLogger(QuizGenerator.class);
	QuizService quizService = new QuizService();
	QuizUI quizUi = new QuizUI();
	public void getQuiz() {
		List<Quiz> quizList = quizService.read();
		quizList.forEach(quiz -> {
			LOGGER.info("-----------------------------------------------");
			LOGGER.log(Level.INFO, "Quiz with Id : {}", quiz.getId());
			LOGGER.log(Level.INFO, "Available Quiz level : {} ", quiz.getCategory());
			LOGGER.log(Level.INFO, "Available Tag : {} ", quiz.getTag());
			LOGGER.info("-----------------------------------------------");
		});
	}
	public void getQuestion() {
		quizUi.showQuestions();
	}
}
