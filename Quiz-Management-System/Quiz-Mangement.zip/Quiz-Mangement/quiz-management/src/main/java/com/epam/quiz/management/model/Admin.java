package com.epam.quiz.management.model;

public class Admin extends User {

	public Admin(String userName, String password, String roleType) {
		super(userName, password, roleType);
	}

}
