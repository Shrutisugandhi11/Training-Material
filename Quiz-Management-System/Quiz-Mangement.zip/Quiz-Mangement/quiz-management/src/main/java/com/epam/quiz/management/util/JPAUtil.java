package com.epam.quiz.management.util;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class JPAUtil {
    private static EntityManagerFactory factory ;

    public static EntityManagerFactory getInstance()
    {
        if(factory == null)
            factory = Persistence.createEntityManagerFactory("quiz-demo");
        return factory;
    }
    private  JPAUtil() {
    }
}
