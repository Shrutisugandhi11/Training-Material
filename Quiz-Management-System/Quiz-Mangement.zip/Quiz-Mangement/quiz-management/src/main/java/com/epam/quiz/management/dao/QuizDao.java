package com.epam.quiz.management.dao;

import com.epam.quiz.management.model.Question;
import com.epam.quiz.management.model.Quiz;
import com.epam.quiz.management.util.JPAUtil;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.TypedQuery;

import java.util.List;

public class QuizDao implements CrudDao<Quiz> {


    EntityManagerFactory entityManagerFactory = JPAUtil.getInstance();
    EntityManager entityManager;

    @Override
    public String create(Quiz quiz) {
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(quiz);
        entityManager.getTransaction().commit();
        entityManager.close();
        return "Quiz created succesfully";
    }

    @Override
    public List<Quiz> read() {
        entityManager = entityManagerFactory.createEntityManager();
        return entityManager.createQuery("from Quiz quiz", Quiz.class).getResultList();
    }

    @Override
    public Quiz readById(int id) {
        entityManager = entityManagerFactory.createEntityManager();
        Quiz quiz = entityManager.find(Quiz.class, id);
        entityManager.close();
        return quiz;
    }

    public List<Quiz> readByTag(String tag) {
        entityManager = entityManagerFactory.createEntityManager();
        return entityManager.createQuery("from Quiz quiz", Quiz.class).getResultList();

    }

    @Override
    public Quiz update(int id, String value) {
        entityManager = entityManagerFactory.createEntityManager();
        Quiz quiz = entityManager.find(Quiz.class, id);
        entityManager.getTransaction().begin();
        quiz.setTag(value);
        entityManager.getTransaction().commit();
        entityManager.close();
        return quiz;
    }

    @Override
    public String delete(int id) {
        String returnString = "";
        entityManager = entityManagerFactory.createEntityManager();
        Quiz quiz = entityManager.find(Quiz.class, id);
        if (quiz == null) {
            returnString = "Quiz not found";
        } else {
            entityManager.getTransaction().begin();
            entityManager.remove(quiz);
            entityManager.getTransaction().commit();
            entityManager.close();
            returnString = "Quiz Deleted Successfully";
        }
        return returnString;

    }

    public List<Question> getQuestionList(String tag) {
        entityManager = entityManagerFactory.createEntityManager();
        TypedQuery<Question> query = entityManager.createQuery("from Question q where q.tag=?1", Question.class);
        query.setParameter(1, tag);
        return query.getResultList();
    }



}
