package com.epam.quiz.management;

import com.epam.quiz.management.exception.CredentialsMismatchException;
import com.epam.quiz.management.exception.InvalidInputException;
import com.epam.quiz.management.exception.ValidationException;
import com.epam.quiz.management.ui.Menu;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class App {
    private static final Logger Logger = LogManager.getLogger(App.class);

    public static void main(String[] args) throws ValidationException, InvalidInputException, CredentialsMismatchException {

        Logger.info("App started");
		Menu menu = new Menu();
        try {

            menu.getDashboard();

        } catch (InvalidInputException e) {
            Logger.error(e.getMessage());
			menu.getDashboard();
        }
    }
}
