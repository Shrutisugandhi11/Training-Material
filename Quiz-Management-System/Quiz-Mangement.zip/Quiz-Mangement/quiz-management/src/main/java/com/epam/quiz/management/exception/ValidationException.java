package com.epam.quiz.management.exception;

public class ValidationException extends Exception{
    public ValidationException(){
        super();
    }
    public ValidationException(String string){
        super(string);
    }
}
